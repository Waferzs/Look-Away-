# Look Away Game
Look Away Game

Overview:
Look Away is a simple game written in C++, where the player is tasked to input the 'w','a','s','d' key that correlates with its direction. 'W' is up, 'a' is left, 's' is down, and'd' is right. As the game progresses, the difficulty increases as well with the time to input said keys getting shorter. In turn, requiring the user to react and input accordingly.

Gameplay:
The game presents an arrow pointing in a direction on the screen
The player must input a character without making that input the same as the one on screen
As time progress, the speed in which the player must input decreases, resulting the game to be more challenging
The game continues until the player runs out of lives.

Purpose:
This project was created as a part of a university asisgnment to develop a C++ application, in which there was no specificed requirement aside from coding it in C++. It serves as a pracitical excercise in using basic game mechanics,
user input handling, and timing functionalities.

How to Play:
1.) Extract file from zip
2.) Run exe file